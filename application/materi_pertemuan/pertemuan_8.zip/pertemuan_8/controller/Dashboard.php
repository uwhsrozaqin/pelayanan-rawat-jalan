<?php
/**
 * 
 */
class Dashboard extends CI_Controller
{
	function index(){
		$this->load->view('dashboard_view');
	}
}
?>